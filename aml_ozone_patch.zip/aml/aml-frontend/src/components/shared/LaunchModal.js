import React from 'react';
import { connect } from 'react-redux';

var { PERMITTED_OZONE_PARENT_DOMAIN } = require('Config');

import { Button, Dialog, Intent, Popover, PopoverInteractionKind, Position } from "@blueprintjs/core";
import Analytics from 'analytics/analytics';
import { createNotification } from 'actions/notification';
import { Notification } from 'services/serializers/notification';
import { ShortListing } from 'services/serializers/listing';
import { SaveableProfile } from 'services/serializers/profile';
import { saveProfile, fetchMyProfile } from 'actions/profile';
import { mapDispatchToProps } from 'components/shared/helpers';
import moment from 'moment';
var timer = null, timeout = null;

export class LaunchModal extends React.Component {
    constructor(props) {
        super(props);
        this.launch = this.launch.bind(this);
        this.submitOwnerMessage = this.submitOwnerMessage.bind(this);

        this.state = {
            openLaunchModal: false,
            isOpen: false,
            timeleft: 45,
            showLeavingWarning: _.get(this.props.user, 'showLeavingWarning'),
            launchNoticeFlag: _.get(this.props.user, 'showLeavingWarning'),
            popupBlocked: false
        };
    }

    componentDidMount() {
        this.props.onRef(this);
        this.setState({timeleft: 45});
    }

    componentWillUnmount() {
        this.reset();
        this.props.onRef(undefined);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.user && this.state.launchNoticeFlag != nextProps.user.showLeavingWarning) {
            this.setState({
                launchNoticeFlag: nextProps.user.showLeavingWarning
            });
        }
    }

    openListing(url) {
        if ( window.parent === undefined || window.parent.location === window.location) {
            return window.open(url);
        }

        // console.log("Chrome:", this.getParentOnChrome());
        // console.log("Edge/IE:", this.getParentOnEdgeAndIE());
        // console.log("FF:", this.tryToGetParentOnFF());

        let parentDomain = this.getParentOnChrome();
        if (parentDomain === "") {
            parentDomain = this.getParentOnEdgeAndIE();
        }
        if (parentDomain === "") {
            parentDomain = this.tryToGetParentOnFF();
        }
        // console.log(parentDomain, PERMITTED_OZONE_PARENT_DOMAIN)

        if (this.urlsEqual(parentDomain, PERMITTED_OZONE_PARENT_DOMAIN) ) { // running inside Ozone
            window.parent.postMessage(this.props.listing, PERMITTED_OZONE_PARENT_DOMAIN);
            return {success: true};
        }
        else if (parentDomain === ""
                    && PERMITTED_OZONE_PARENT_DOMAIN !== undefined
                    && PERMITTED_OZONE_PARENT_DOMAIN !== "" ) {
            // if this is embedded somewhere, but we can't tell where, and the system has been set up to allow it to be
            // embedded in Ozone, then just send a message in case it's Ozone, and also open it normally in case it isn't.
            // Annoying for Ozone users, but ensures nothing changes for anyone else using AML.
            window.parent.postMessage(this.props.listing, PERMITTED_OZONE_PARENT_DOMAIN);
            return window.open(url);
        }
        // console.log ("opening normally")
        return window.open(url);
    }

    getParentOnChrome() {
        if (document.location.ancestorOrigins && document.location.ancestorOrigins.length > 0) {
            return document.location.ancestorOrigins[0];
        }
        return "";
    }
    getParentOnEdgeAndIE() {
        if (window.parent && window.parent.location) {
            try {
                return window.parent.location.href;
            } catch (e) {
                try {
                    return window.parent.location.origin;
                } catch (e) {
                    return "";
                }
            }
        }
        return "";
    }
    tryToGetParentOnFF() {
        if (document.referrer && window.location && !this.urlsEqual(document.referrer, window.location.origin)) {
            return document.referrer;
        }
        return "";
    }

    urlsEqual(url1, url2) {
        if (url1 === "" || url2 === "" || url1 === undefined || url2 === undefined) {
            return false;
        }
        if (url1.slice(-1) === "/" && url2.slice(-1) !== "/") {
            url1 = url1.slice(0,-1);
        }
        else if (url1.slice(-1) !== "/" && url2.slice(-1) === "/") {
            url1 += "/";
        }

        return url1 === url2;
    }


    launch(e, url){
        var me = this;
        if (this.state.launchNoticeFlag) {
            this.toggleDialog();

            timeout = setTimeout(function(){
                me.reset();
                me.toggleDialog();
            }, me.state.timeleft*1000);

            timer = setInterval(function(){
                me.setState({timeleft:me.state.timeleft-1});
                if(me.state.timeleft <= 0)
                    clearInterval(timer);
            }, 1000);

            setTimeout(function() {
                var application = me.openListing(url);
                if (application == null || typeof(application) == 'undefined') {
                    me.setState({
                        popupBlocked: true
                    });
                }
            }, 3000);
        } else {
            me.openListing(url);
        }

        Analytics.trackEvent('Applications', this.props.listing.title, this.props.listing.agencyShort);

        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();
    }

    reset(){
        clearTimeout(timeout);
        clearInterval(timer);
    }

    cancelTimer(e){
        this.reset();
        e.preventDefault();
        e.stopPropagation();
    }

    toggleDialog() {
        this.setState({
            isOpen: !this.state.isOpen,
            timeleft: 45,
            popupBlocked: false,
        });
        this.reset();
    }

    handleChange(e) {
        if (e.target.value == 'true' || e.target.value == true) {
            this.setState({
                launchNoticeFlag: false
            });
        } else {
            this.setState({
                launchNoticeFlag: true
            })
        }
    }

    submitOwnerMessage() {
        var date = new Date();
        var expiresDate = new Date(
            Date.UTC(date.getFullYear(), date.getMonth()+1, date.getDate())
        );
        expiresDate = moment(expiresDate).format('YYYY-MM-DDThh:mmZ');

        var { listing, user} = this.props;
        var message = this.refs.ownerMessage.value;
        if(!message) {
            return;
        }

        message =
            user.displayName +
            " has sent a notification in regards to the listing " +
            listing.title +
            ":<br><br>" +
            message;

        var shortListing = new ShortListing();
        shortListing.id = listing.id;

        var notification = new Notification();
        notification.expirationDate = String(expiresDate);
        notification.message = message;
        notification.listing = shortListing;
        notification.type = "ListingOwnerNotification";

        this.props.dispatch(createNotification(notification));
        this.toggleDialog();
        return;
    }

    confirm() {
        this.toggleDialog();

        if (!this.state.launchNoticeFlag) {
            var profile = new SaveableProfile();
            profile.showLeavingWarning = this.state.launchNoticeFlag;

            this.props.dispatch(saveProfile(profile));
        }
    }

    render() {
        var { listing } = this.props;

        return (
                <div className="text-center">
                    {this.state.isOpen &&
                        <Dialog
                            isOpen={this.state.isOpen}
                            onClose={() => this.toggleDialog()}
                            title={'Notice: You are leaving AppsMall!'}>
                            <div className="pt-card pt-elevation-2">
                                <div className="pt-dialog-body">
                                    <span>Please review the requirements below if you have problems launching {listing.title}:</span>
                                </div>
                                <div className="row">
                                    <div className="requirements pt-dialog-body col-md-4 col-lg-4">
                                        <h5>Usage Requirements</h5>
                                        <span>{listing.usageRequirements}</span>
                                    </div>
                                    <div className="requirements pt-dialog-body col-md-4 col-lg-4">
                                        <h5>System Requirements</h5>
                                        <span>{listing.systemRequirements}</span>
                                    </div>
                                </div>
                                <div className="pt-dialog-body">
                                    <div>Or contact the owners of {listing.title} here:</div>
                                    <Popover
                                        usePortal={false}
                                        interactionKind={PopoverInteractionKind.CLICK}
                                        popoverClassName="pt-popover-content-sizing"
                                        position={Position.RIGHT}
                                        >
                                            <Button className="btn btn-primary contact" intent={Intent.PRIMARY}>Contact</Button>
                                            <div>
                                                <div>
                                                <h5>Send a message to the {'owner' + (listing && listing.owners.length == 1 ? '' : 's')}</h5>
                                                <textarea type="text" dir="auto" ref="ownerMessage" />
                                                </div>
                                                <button className="pt-button pt-intent-danger pt-popover-dismiss">Dismiss</button>
                                                <button className="pt-button pt-intent-primary pt-popover-dismiss" onClick={this.submitOwnerMessage}>Send</button>
                                            </div>
                                        </Popover>
                                    </div>
                            </div>
                            <div className="pt-dialog-footer">
                                <div className="timer-cancel">This window will close automatically in {this.state.timeleft} seconds
                                    <a href="#" onClick={(e) => this.cancelTimer(e)}> [cancel]</a>
                                </div>
                                <div className="pt-dialog-footer-actions">
                                    <div>
                                        <Button className="pt-dialog-footer-submit-button pt-intent-primary launch-ok" onClick={() => this.confirm()}>OK</Button>
                                    </div>
                                    <div className="do-not-show">
                                        <input className="pt-dialog-footer-checkbox" id="launchModalSubscription" type="checkbox" onChange={this.handleChange.bind(this)} value={this.state.launchNoticeFlag}/>
                                        <label className="pt-dialog-footer-checkbox-label">do not show again</label>
                                    </div>
                                </div>
                            </div>
                        </Dialog>}
                        {this.state.popupBlocked &&
                            <Dialog
                                isOpen={this.state.popupBlocked}
                                onClose={() => this.setState({popupBlocked: false})}
                                title={'Pop-up blocked!'}>
                                    <div className="pt-dialog-body">
                                        <span>Click 'Launch Application' to open manually.</span>
                                    </div>
                                    <div className="pt-dialog-footer">
                                        <div className="pt-dialog-footer-actions">
                                            <Button className="pt-intent-danger" onClick={() => this.setState({popupBlocked: false})}>Cancel</Button>
                                            <Button className="pt-intent-primary" onClick={() => this.openListing(listing.launchUrl)}>Launch Application</Button>
                                        </div>
                                    </div>
                            </Dialog>}
                </div>
        );
    }
}

function mapStateToProps(state, ownProps) {
    return {
        user: state.profile.getMyProfile.result,
    };
}

export default connect(mapStateToProps, mapDispatchToProps) (LaunchModal)
