const merge = require('webpack-merge');
const common = require('./webpack.common.js');

module.exports = merge(common, {
    externals: {
        'Config': JSON.stringify({
            API_URL: (process.env && process.env.API_URL) ? process.env.API_URL : "http://localhost:8001",
            NODE_ENV: "development",
            WEBSOCKET_URL: (process.env && process.env.WEBSOCKET_URL) ? process.env.WEBSOCKET_URL : "http://localhost:4200",
            USE_WEBSOCKET: (process.env && process.env.USE_WEBSOCKET) ? process.env.USE_WEBSOCKET === 'true' : true,
            SHOW_THEME_IN_MENU: (process.env && process.env.SHOW_THEME_IN_MENU) ? process.env.SHOW_THEME_IN_MENU === 'true' : true,
            APP_TITLE: 'AppsMall',
            METRICS_URL: '//172.16.105.48/metrics/',
            METRICS_SITE_ID: 2,
            CONTACT_HELP_DESK_URL: 'http://localhost/help_desk',
            CONTACT_SUBMIT_REQUEST_URL: 'http://localhost/request',
            CONTACT_GIVE_FEEDBACK_EMAIL: 'mailto:feedback@address.com',
            CONTACT_CONNECT_CHIRP_URL: 'http://localhost/chirp',
            CONTACT_CONNECT_CHAT_URL: 'http://localhost/chat',
            CONTACT_CONNECT_BLOG_URL: 'http://localhost/blog',
            PERMITTED_OZONE_PARENT_DOMAIN: 'http://localhost:3000',
        })
    },
});
