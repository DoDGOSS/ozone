const merge = require('webpack-merge');
const common = require('./webpack.common.js');

module.exports = merge(common, {
    externals: {
        'Config': JSON.stringify({
            API_URL: (process.env && process.env.API_URL) ? process.env.API_URL : "http://192.168.1.8:8001",
            NODE_ENV: "production",
            WEBSOCKET_URL: (process.env && process.env.WEBSOCKET_URL) ? process.env.WEBSOCKET_URL : "http://192.168.1.8:4200",
            USE_WEBSOCKET: (process.env && process.env.USE_WEBSOCKET) ? process.env.USE_WEBSOCKET === 'true' : true,
            SHOW_THEME_IN_MENU: (process.env && process.env.SHOW_THEME_IN_MENU) ? process.env.SHOW_THEME_IN_MENU === 'true' : false,
            APP_TITLE: 'AppsMall',
            METRICS_URL: 'PLACEHOLDER',
            METRICS_SITE_ID: 0,
            CONTACT_HELP_DESK_URL: 'PLACEHOLDER',
            CONTACT_SUBMIT_REQUEST_URL: 'PLACEHOLDER',
            CONTACT_GIVE_FEEDBACK_EMAIL: 'mailto:PLACEHOLDER',
            CONTACT_CONNECT_CHIRP_URL: 'PLACEHOLDER',
            CONTACT_CONNECT_CHAT_URL: 'PLACEHOLDER',
            CONTACT_CONNECT_BLOG_URL: 'PLACEHOLDER',
            PERMITTED_OZONE_PARENT_DOMAIN: 'http://192.168.1.8:3000/',
        })
    },
});
